create view user_data as
  select `bd`.`user`.`id`       AS `id`,
         `bd`.`user`.`name`     AS `name`,
         `bd`.`user`.`email`    AS `email`,
         `bd`.`user`.`password` AS `password`,
         `bd`.`role`.`id`       AS `role_id`,
         `bd`.`role`.`name`     AS `role`
  from (`bd`.`user` join `bd`.`role` on ((`bd`.`user`.`role_id` = `bd`.`role`.`id`)));

