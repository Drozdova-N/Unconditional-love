create view application_from as
  select `student`.`application`.`idapplication` AS `id`,
         `student`.`pets`.`idpets`               AS `idpets`,
         `student`.`user`.`id`                   AS `iduser`,
         `student`.`user`.`email`                AS `email`,
         `student`.`user`.`name`                 AS `name`,
         `student`.`pets`.`nickname`             AS `nickname`,
         `student`.`pets`.`photo`                AS `photo`,
         `student`.`application`.`message`       AS `message`,
         `student`.`application`.`state`         AS `state`
  from ((`student`.`application` join `student`.`pets` on ((`student`.`application`.`id_pets` =
                                                            `student`.`pets`.`idpets`))) join `student`.`user` on ((
    `student`.`application`.`id_user` = `student`.`user`.`id`)));

