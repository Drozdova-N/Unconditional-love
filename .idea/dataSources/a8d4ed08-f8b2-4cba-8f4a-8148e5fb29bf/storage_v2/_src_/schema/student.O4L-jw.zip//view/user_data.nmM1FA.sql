create view user_data as
  select `student`.`user`.`id`       AS `id`,
         `student`.`user`.`name`     AS `name`,
         `student`.`user`.`email`    AS `email`,
         `student`.`user`.`password` AS `password`,
         `student`.`role`.`id`       AS `role_id`,
         `student`.`role`.`name`     AS `role`
  from (`student`.`user` join `student`.`role` on ((`student`.`user`.`role_id` = `student`.`role`.`id`)));

